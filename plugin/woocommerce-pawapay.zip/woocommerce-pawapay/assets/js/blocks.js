/* global wc, wp */
( function () {
	'use strict';

	const { registerPaymentMethod } = wc.wcBlocksRegistry;
	const { getSetting } = wc.wcSettings;
	const { createElement, useState, useEffect, useRef } = wp.element;
	const { decodeEntities } = wp.htmlEntities;
	const { __ } = wp.i18n;

	const settings = getSetting( 'pawapay_data', {} );
	const i18n = settings.i18n || {};
	const title = decodeEntities( settings.title || __( 'Mobile Money', 'woocommerce-pawapay' ) );

	/**
	 * The checkout-form fields shown under the payment method.
	 * Captures the phone number, predicts the provider, and exposes the
	 * collected data to the Blocks checkout via onPaymentSetup.
	 */
	const Content = ( props ) => {
		const { eventRegistration, emitResponse } = props;
		const { onPaymentSetup } = eventRegistration;

		const [ phone, setPhone ] = useState( '' );
		const [ provider, setProvider ] = useState( '' );
		const [ otp, setOtp ] = useState( '' );
		const [ authType, setAuthType ] = useState( 'PROVIDER_AUTH' );
		const [ note, setNote ] = useState( '' );
		const debounceRef = useRef( null );

		// Predict the provider as the customer types (debounced).
		useEffect( () => {
			if ( debounceRef.current ) {
				clearTimeout( debounceRef.current );
			}
			const value = phone.trim();
			if ( value.replace( /\D/g, '' ).length < 6 ) {
				setProvider( '' );
				setNote( '' );
				return;
			}
			setNote( i18n.detecting || 'Checking number…' );
			debounceRef.current = setTimeout( () => {
				fetch( settings.validateUrl, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': settings.nonce || '',
					},
					body: JSON.stringify( { phone: value } ),
				} )
					.then( ( r ) => r.json() )
					.then( ( data ) => {
						if ( ! data || ! data.ok ) {
							setProvider( '' );
							setNote( ( data && data.error ) || i18n.invalid || '' );
							return;
						}
						setProvider( data.provider || '' );
						setAuthType( data.authType || 'PROVIDER_AUTH' );
						const name = data.displayName || data.provider || '';
						setNote( ( i18n.detected || 'Detected provider:' ) + ' ' + name );
					} )
					.catch( () => {
						setNote( '' );
					} );
			}, 500 );
			return () => {
				if ( debounceRef.current ) {
					clearTimeout( debounceRef.current );
				}
			};
		}, [ phone ] );

		// Hand the collected payment data to the Store API on checkout submit.
		useEffect( () => {
			const unsubscribe = onPaymentSetup( () => {
				const cleaned = phone.trim();
				if ( cleaned.replace( /\D/g, '' ).length < 6 ) {
					return {
						type: emitResponse.responseTypes.ERROR,
						message: i18n.required || 'Please enter your mobile money phone number.',
					};
				}
				return {
					type: emitResponse.responseTypes.SUCCESS,
					meta: {
						paymentMethodData: {
							pawapay_phone: cleaned,
							pawapay_provider: provider,
							pawapay_otp: otp,
						},
					},
				};
			} );
			return unsubscribe;
		}, [ onPaymentSetup, phone, provider, otp, emitResponse.responseTypes ] );

		const children = [];

		if ( settings.description ) {
			children.push(
				createElement( 'p', { key: 'desc' }, decodeEntities( settings.description ) )
			);
		}

		children.push(
			createElement(
				'label',
				{ key: 'lbl', htmlFor: 'pawapay_phone_block', style: { display: 'block', marginBottom: '4px' } },
				i18n.phoneLabel || 'Mobile money phone number'
			)
		);
		children.push(
			createElement( 'input', {
				key: 'phone',
				id: 'pawapay_phone_block',
				type: 'tel',
				inputMode: 'tel',
				autoComplete: 'tel',
				className: 'wc-pawapay-block-input',
				placeholder: i18n.phonePlaceholder || '',
				value: phone,
				onChange: ( e ) => setPhone( e.target.value ),
				style: { width: '100%', padding: '8px', boxSizing: 'border-box' },
			} )
		);
		if ( note ) {
			children.push(
				createElement( 'p', { key: 'note', className: 'wc-pawapay-block-note', style: { marginTop: '6px', fontSize: '0.9em' } }, note )
			);
		}

		// PREAUTH providers (e.g. Orange Burkina Faso) need an OTP up front.
		if ( authType === 'PREAUTH' ) {
			children.push(
				createElement(
					'label',
					{ key: 'otplbl', htmlFor: 'pawapay_otp_block', style: { display: 'block', margin: '8px 0 4px' } },
					i18n.otpLabel || 'Authorisation code (OTP)'
				)
			);
			children.push(
				createElement( 'input', {
					key: 'otp',
					id: 'pawapay_otp_block',
					type: 'text',
					inputMode: 'numeric',
					value: otp,
					onChange: ( e ) => setOtp( e.target.value ),
					style: { width: '100%', padding: '8px', boxSizing: 'border-box' },
				} )
			);
		}

		return createElement( 'div', { className: 'wc-pawapay-block-fields' }, children );
	};

	const Label = () => {
		return createElement( 'span', null, title );
	};

	registerPaymentMethod( {
		name: settings.name || 'pawapay',
		label: createElement( Label, null ),
		ariaLabel: title,
		content: createElement( Content, null ),
		edit: createElement( Content, null ),
		canMakePayment: () => true,
		supports: {
			features: settings.supports || [ 'products', 'refunds' ],
		},
	} );
} )();
