/* global jQuery, wcPawaPay */
( function ( $ ) {
	'use strict';

	if ( typeof wcPawaPay === 'undefined' ) {
		return;
	}

	const i18n = wcPawaPay.i18n || {};

	/* -------------------------------------------------------------- *
	 * Classic checkout: predict provider, reveal OTP for PREAUTH.
	 * -------------------------------------------------------------- */
	let debounce = null;

	function validatePhone() {
		const $phone = $( '#pawapay_phone' );
		if ( ! $phone.length ) {
			return;
		}
		const value = ( $phone.val() || '' ).trim();
		const $info = $( '#pawapay_provider_info' );
		const $providerField = $( '#pawapay_provider' );

		if ( value.replace( /\D/g, '' ).length < 6 ) {
			$info.text( '' );
			$providerField.val( '' );
			$( '#pawapay_otp_row' ).hide();
			return;
		}

		$info.text( i18n.detecting || '' );

		$.ajax( {
			url: wcPawaPay.validateUrl,
			method: 'POST',
			contentType: 'application/json',
			headers: { 'X-WP-Nonce': wcPawaPay.nonce },
			data: JSON.stringify( { phone: value } ),
		} )
			.done( function ( data ) {
				if ( ! data || ! data.ok ) {
					$info.text( ( data && data.error ) || i18n.invalid || '' );
					$providerField.val( '' );
					$( '#pawapay_otp_row' ).hide();
					return;
				}
				$providerField.val( data.provider || '' );
				const name = data.displayName || data.provider || '';
				$info.text( ( i18n.detected || '' ) + ' ' + name );

				if ( data.authType === 'PREAUTH' ) {
					$( '#pawapay_otp_row' ).show();
				} else {
					$( '#pawapay_otp_row' ).hide();
				}
			} )
			.fail( function () {
				$info.text( '' );
			} );
	}

	$( document.body ).on( 'input', '#pawapay_phone', function () {
		clearTimeout( debounce );
		debounce = setTimeout( validatePhone, 500 );
	} );

	/* -------------------------------------------------------------- *
	 * Order-received page: poll for the final payment state.
	 * -------------------------------------------------------------- */
	function startPolling() {
		if ( ! wcPawaPay.poll || ! wcPawaPay.orderId ) {
			return;
		}

		const $target = $( '.woocommerce-order' ).first();
		const $banner = $( '<div class="wc-pawapay-status woocommerce-info" aria-live="polite"></div>' );
		if ( $target.length ) {
			$target.prepend( $banner );
		} else {
			$( '.entry-content, .woocommerce' ).first().prepend( $banner );
		}
		$banner.text( i18n.waiting || '' );

		const url = wcPawaPay.statusUrl +
			'?order_id=' + encodeURIComponent( wcPawaPay.orderId ) +
			'&key=' + encodeURIComponent( wcPawaPay.orderKey );

		let attempts = 0;
		const maxAttempts = 60; // ~3 minutes at 3s intervals.

		function poll() {
			attempts++;
			$.ajax( { url: url, method: 'GET', headers: { 'X-WP-Nonce': wcPawaPay.nonce } } )
				.done( function ( data ) {
					if ( ! data || ! data.state ) {
						schedule();
						return;
					}

					// REDIRECT_AUTH (e.g. Wave): send the customer to authorise.
					if ( data.authorizationUrl ) {
						window.location.href = data.authorizationUrl;
						return;
					}

					switch ( data.state ) {
						case 'COMPLETED':
							$banner.removeClass( 'woocommerce-info woocommerce-error' )
								.addClass( 'woocommerce-message' )
								.text( i18n.completed || '' );
							// Reload ONCE so the page reflects the paid order status,
							// then stop — guard against an infinite reload loop.
							try {
								var doneKey = 'wcPawaPayDone_' + wcPawaPay.orderId;
								if ( window.sessionStorage && ! sessionStorage.getItem( doneKey ) ) {
									sessionStorage.setItem( doneKey, '1' );
									window.location.reload();
								}
							} catch ( e ) {
								/* sessionStorage unavailable — just stop polling. */
							}
							return;

						case 'FAILED':
							$banner.removeClass( 'woocommerce-info woocommerce-message' )
								.addClass( 'woocommerce-error' )
								.text( data.failureMessage || i18n.failed || '' );
							return;

						default:
							if ( data.lifecycle === 'ENQUEUED' ) {
								$banner.text( i18n.enqueued || '' );
							} else if ( data.lifecycle === 'IN_RECONCILIATION' ) {
								$banner.text( i18n.reconciling || '' );
							} else {
								$banner.text( i18n.waiting || '' );
							}
							schedule();
					}
				} )
				.fail( function () {
					schedule();
				} );
		}

		function schedule() {
			if ( attempts < maxAttempts ) {
				setTimeout( poll, 3000 );
			} else {
				$banner.text( i18n.reconciling || '' );
			}
		}

		poll();
	}

	$( startPolling );
} )( jQuery );
