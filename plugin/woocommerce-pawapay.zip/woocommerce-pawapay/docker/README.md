# Local test stack — pawaPay for WooCommerce

A throwaway WordPress + WooCommerce environment with the plugin pre-installed,
for testing against the pawaPay **sandbox**.

## Requirements

- Docker + Docker Compose v2 (`docker compose`, not the old `docker-compose`).

## Start

```bash
cd docker
docker compose up -d
# wait ~30–60s for the wpcli provisioner to finish:
docker compose logs -f wpcli
```

When `wpcli` prints "pawaPay test store is ready" and exits:

- Storefront: http://localhost:8080
- Admin: http://localhost:8080/wp-admin — **admin / admin**

The plugin folder (one level up from `docker/`) is bind-mounted live, so PHP/JS
edits are reflected on the next request — no rebuild needed.

## Configure the gateway

1. WooCommerce → Settings → Payments → **pawaPay (Mobile Money)**.
2. Environment: **Sandbox**.
3. Paste your **sandbox API token** (https://dashboard.sandbox.pawapay.io/).
4. Enable the gateway and save. On save the plugin calls `active-conf` and shows
   your connected company name — confirming the token works.
5. (Optional) Tick **Sign requests**, add your sandbox key ID + ECDSA P-256 PEM.
   If the key is missing/invalid, signing is auto-disabled with an error.

The default store currency is **GHS** (Ghana). Change it under
WooCommerce → Settings → General to test other markets — it must be a currency
pawaPay supports for your target country.

## Place a test order

- **Blocks checkout**: http://localhost:8080/checkout/ (WooCommerce default).
- **Classic checkout**: http://localhost:8080/classic-checkout/

Use a sandbox MSISDN (the last 3 digits drive the outcome). For GHS / MTN Ghana:

| MSISDN          | Outcome                          |
|-----------------|----------------------------------|
| `233593456789`  | COMPLETED (success)              |
| `233593456049`  | FAILED — INSUFFICIENT_BALANCE    |
| `233593456039`  | FAILED — PAYMENT_NOT_APPROVED    |
| `233593456029`  | FAILED — PAYER_NOT_FOUND         |

The order-received page polls pawaPay's status-check endpoint, so the **happy
path and failure paths resolve locally without any public callback URL.**

## Testing callbacks (optional)

pawaPay pushes callbacks from a fixed IP to a public HTTPS URL, so callback
delivery can't reach `localhost`. To test it, run the bundled ngrok tunnel:

```bash
cp .env.example .env        # add your NGROK_AUTHTOKEN
docker compose --profile tunnel up -d ngrok
# find the public URL:
open http://localhost:4040   # ngrok inspector
```

Then in the **sandbox dashboard** (Settings → System config → Callback URLs),
set the DEPOSIT and REFUND callback URL to:

```
https://<your-ngrok-subdomain>.ngrok-free.app/wp-json/wc-pawapay/v1/callback
```

Callbacks are matched to orders by `depositId`/`refundId`, so they work even
though WordPress's own site URL stays `localhost`.

## Reconciliation cron

The plugin schedules a WP-Cron event every 5 minutes. WP-Cron only fires on page
traffic; to force a run:

```bash
docker compose run --rm --entrypoint wp wpcli cron event run wc_pawapay_reconcile
```

(The `wordpress` Apache image has no WP-CLI; the `wpcli` image does.)

## Logs

```bash
# Plugin debug log (enable "Debug logging" in the gateway settings first):
docker compose exec wordpress sh -c 'tail -f wp-content/uploads/wc-logs/*.log'
# WordPress debug log:
docker compose exec wordpress sh -c 'tail -f wp-content/debug.log'
```

## Reset / teardown

```bash
docker compose down          # stop, keep data
docker compose down -v       # stop and wipe the WP + DB volumes (fresh start)
```
