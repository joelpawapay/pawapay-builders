#!/bin/sh
# One-shot provisioning for the pawaPay test store. Idempotent — safe to re-run.
set -e

cd /var/www/html

echo "==> Waiting for wp-config.php (created by the wordpress container)…"
i=0
until [ -f wp-config.php ]; do
	i=$((i + 1))
	if [ "$i" -gt 60 ]; then
		echo "wp-config.php never appeared; aborting." >&2
		exit 1
	fi
	sleep 2
done

echo "==> Waiting for the database + installing WordPress core…"
until wp core is-installed >/dev/null 2>&1; do
	wp core install \
		--url="$SITE_URL" \
		--title="$SITE_TITLE" \
		--admin_user="$ADMIN_USER" \
		--admin_password="$ADMIN_PASSWORD" \
		--admin_email="$ADMIN_EMAIL" \
		--skip-email >/dev/null 2>&1 || true
	sleep 3
done
echo "    WordPress is installed."

# Pretty permalinks so REST routes resolve at /wp-json/... (REST also works via
# ?rest_route= as a fallback, but this keeps the callback URL clean).
wp rewrite structure '/%postname%/' --hard >/dev/null 2>&1 || true
wp rewrite flush --hard >/dev/null 2>&1 || true

echo "==> Installing + activating WooCommerce…"
wp plugin is-active woocommerce >/dev/null 2>&1 || wp plugin install woocommerce --activate

echo "==> Activating pawaPay for WooCommerce…"
wp plugin is-active woocommerce-pawapay >/dev/null 2>&1 || wp plugin activate woocommerce-pawapay

echo "==> Configuring store (currency=$STORE_CURRENCY, country=$STORE_COUNTRY)…"
wp option update woocommerce_currency "$STORE_CURRENCY"
wp option update woocommerce_default_country "$STORE_COUNTRY"
wp option update woocommerce_store_country "$STORE_COUNTRY"
wp option update woocommerce_enable_guest_checkout "yes"
wp option update woocommerce_enable_signup_and_login_from_checkout "no"
# Suppress the onboarding wizard / marketing nags.
wp option update woocommerce_task_list_hidden "yes" >/dev/null 2>&1 || true
wp option update woocommerce_allow_tracking "no" >/dev/null 2>&1 || true
# Disable "Launch Your Store" coming-soon mode so the storefront is public
# (otherwise only logged-in admins can see it).
wp option update woocommerce_coming_soon "no"
wp option update woocommerce_store_pages_only "no"

echo "==> Creating a sample product (if none exists)…"
if ! wp post list --post_type=product --field=ID | grep -q .; then
	wp wc product create \
		--name="Test Mobile Money Product" \
		--type=simple \
		--regular_price=10 \
		--status=publish \
		--user="$ADMIN_USER" >/dev/null
	echo "    Sample product created (price 10 $STORE_CURRENCY)."
fi

echo "==> Creating a classic-checkout page (for testing the non-Blocks flow)…"
if ! wp post list --post_type=page --field=post_title | grep -q "Classic Checkout"; then
	wp post create \
		--post_type=page \
		--post_status=publish \
		--post_title="Classic Checkout" \
		--post_content="[woocommerce_checkout]" >/dev/null
	echo "    Classic Checkout page created at $SITE_URL/classic-checkout/"
fi

echo ""
echo "============================================================"
echo " pawaPay test store is ready."
echo "   Storefront : $SITE_URL"
echo "   Admin      : $SITE_URL/wp-admin  ($ADMIN_USER / $ADMIN_PASSWORD)"
echo "   Gateway    : WooCommerce → Settings → Payments → pawaPay"
echo ""
echo " Next: open the gateway settings, choose Sandbox, paste your"
echo " sandbox API token, enable the gateway, then place a test order"
echo " using a sandbox MSISDN (e.g. 233593456789 = COMPLETED on GHS)."
echo "============================================================"
