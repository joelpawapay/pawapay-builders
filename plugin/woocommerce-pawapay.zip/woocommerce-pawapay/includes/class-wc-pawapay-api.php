<?php
/**
 * pawaPay Merchant API v2 HTTP client.
 *
 * Direct HTTP calls (no SDK) over wp_remote_request. Handles bearer auth,
 * optional RFC 9421 signing of financial-initiation calls, and transient
 * caching of read-only config (active-conf, public keys).
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

class WC_PawaPay_API {

	const SANDBOX_BASE    = 'https://api.sandbox.pawapay.io';
	const PRODUCTION_BASE = 'https://api.pawapay.io';

	/** @var string */
	protected $base;
	/** @var string */
	protected $authority;
	/** @var string */
	protected $token;
	/** @var bool */
	protected $sign_enabled;
	/** @var string */
	protected $private_key;
	/** @var string */
	protected $key_id;
	/** @var string */
	protected $environment;

	/**
	 * @param array $config Resolved config (token/keys for the active environment).
	 */
	public function __construct( $config ) {
		$this->environment  = isset( $config['environment'] ) ? $config['environment'] : 'sandbox';
		$this->base         = 'production' === $this->environment ? self::PRODUCTION_BASE : self::SANDBOX_BASE;
		$this->authority    = wp_parse_url( $this->base, PHP_URL_HOST );
		$this->token        = isset( $config['token'] ) ? trim( (string) $config['token'] ) : '';
		$this->sign_enabled = ! empty( $config['sign_enabled'] );
		$this->private_key  = isset( $config['private_key'] ) ? (string) $config['private_key'] : '';
		$this->key_id       = isset( $config['key_id'] ) ? trim( (string) $config['key_id'] ) : '';
	}

	/**
	 * Build an instance from saved gateway settings for the active environment.
	 *
	 * @param array|null $settings Optional settings override.
	 * @return WC_PawaPay_API
	 */
	public static function from_settings( $settings = null ) {
		if ( null === $settings ) {
			$settings = get_option( 'woocommerce_' . WC_PAWAPAY_GATEWAY_ID . '_settings', array() );
		}
		$env = isset( $settings['environment'] ) ? $settings['environment'] : 'sandbox';
		if ( 'production' === $env ) {
			$config = array(
				'environment'  => 'production',
				'token'        => isset( $settings['production_api_token'] ) ? $settings['production_api_token'] : '',
				'sign_enabled' => isset( $settings['enable_signing'] ) && 'yes' === $settings['enable_signing'],
				'private_key'  => isset( $settings['production_private_key'] ) ? $settings['production_private_key'] : '',
				'key_id'       => isset( $settings['production_key_id'] ) ? $settings['production_key_id'] : '',
			);
		} else {
			$config = array(
				'environment'  => 'sandbox',
				'token'        => isset( $settings['sandbox_api_token'] ) ? $settings['sandbox_api_token'] : '',
				'sign_enabled' => isset( $settings['enable_signing'] ) && 'yes' === $settings['enable_signing'],
				'private_key'  => isset( $settings['sandbox_private_key'] ) ? $settings['sandbox_private_key'] : '',
				'key_id'       => isset( $settings['sandbox_key_id'] ) ? $settings['sandbox_key_id'] : '',
			);
		}
		return new self( $config );
	}

	public function get_environment() {
		return $this->environment;
	}

	public function signed_callbacks_supported() {
		return $this->sign_enabled && '' !== $this->private_key;
	}

	/**
	 * Core request. Returns a normalised array:
	 *   array( 'ok' => bool, 'code' => int, 'data' => array|null, 'error' => string|null )
	 *
	 * @param string     $method HTTP method.
	 * @param string     $path   Path beginning with /.
	 * @param array|null $body   Body to JSON-encode, or null for GET.
	 * @param bool       $sign   Whether to sign (financial-initiation endpoints).
	 * @return array
	 */
	public function request( $method, $path, $body = null, $sign = false ) {
		if ( '' === $this->token ) {
			return $this->fail( 0, __( 'pawaPay API token is not configured.', 'woocommerce-pawapay' ) );
		}

		$headers = array(
			'Authorization' => 'Bearer ' . $this->token,
			'Accept'        => 'application/json',
		);

		$body_bytes = null;
		if ( null !== $body ) {
			$body_bytes              = wp_json_encode( $body );
			$headers['Content-Type'] = WC_PawaPay_Signer::CONTENT_TYPE;

			if ( $sign && $this->sign_enabled ) {
				$sig_headers = WC_PawaPay_Signer::sign_request(
					$method,
					$this->authority,
					$path,
					$body_bytes,
					$this->private_key,
					$this->key_id
				);
				if ( is_wp_error( $sig_headers ) ) {
					WC_PawaPay_Logger::error( 'Signing failed: ' . $sig_headers->get_error_message() );
					return $this->fail( 0, $sig_headers->get_error_message() );
				}
				$headers = array_merge( $headers, $sig_headers );
			}
		}

		$args = array(
			'method'  => $method,
			'headers' => $headers,
			'timeout' => ( 'GET' === $method ) ? 8 : 12,
		);
		if ( null !== $body_bytes ) {
			$args['body'] = $body_bytes;
		}

		$response = wp_remote_request( $this->base . $path, $args );

		if ( is_wp_error( $response ) ) {
			WC_PawaPay_Logger::error( $method . ' ' . $path . ' transport error: ' . $response->get_error_message() );
			return $this->fail( 0, $response->get_error_message(), true );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		WC_PawaPay_Logger::log( $method . ' ' . $path . ' -> HTTP ' . $code );

		return array(
			'ok'    => ( $code >= 200 && $code < 300 ),
			'code'  => $code,
			'data'  => is_array( $data ) ? $data : null,
			'error' => null,
		);
	}

	/**
	 * Standard failure envelope. $transport flags "unknown" results (timeouts).
	 */
	protected function fail( $code, $message, $transport = false ) {
		return array(
			'ok'        => false,
			'code'      => $code,
			'data'      => null,
			'error'     => $message,
			'transport' => $transport,
		);
	}

	/* ------------------------------------------------------------------ *
	 * Toolkit endpoints
	 * ------------------------------------------------------------------ */

	/**
	 * Sanitise a phone number and predict its provider.
	 *
	 * @param string $phone Raw customer input.
	 * @return array {ok, provider, country, phoneNumber} or {ok:false, error}.
	 */
	public function predict_provider( $phone ) {
		$res = $this->request( 'POST', '/v2/predict-provider', array( 'phoneNumber' => (string) $phone ) );
		if ( ! $res['ok'] || ! is_array( $res['data'] ) ) {
			$msg = $this->extract_failure_message( $res, __( 'We could not validate that phone number.', 'woocommerce-pawapay' ) );
			return array( 'ok' => false, 'error' => $msg );
		}
		$data = $res['data'];
		if ( isset( $data['failureReason'] ) ) {
			return array( 'ok' => false, 'error' => __( 'That phone number does not match a supported mobile money provider.', 'woocommerce-pawapay' ) );
		}
		return array(
			'ok'          => true,
			'provider'    => isset( $data['provider'] ) ? $data['provider'] : '',
			'country'     => isset( $data['country'] ) ? $data['country'] : '',
			'phoneNumber' => isset( $data['phoneNumber'] ) ? $data['phoneNumber'] : '',
		);
	}

	/**
	 * Fetch (and cache) active-conf for a country/operation.
	 *
	 * @param string $country ISO-3 country, or ''.
	 * @param string $op      Operation type, or ''.
	 * @return array|null Decoded config, or null on failure.
	 */
	public function get_active_conf( $country = '', $op = 'DEPOSIT' ) {
		$cache_key = 'wc_pawapay_conf_' . $this->environment . '_' . strtolower( $country . '_' . $op );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$query = array();
		if ( '' !== $country ) {
			$query['country'] = $country;
		}
		if ( '' !== $op ) {
			$query['operationType'] = $op;
		}
		$path = '/v2/active-conf' . ( $query ? '?' . http_build_query( $query ) : '' );

		$res = $this->request( 'GET', $path );
		if ( ! $res['ok'] || ! is_array( $res['data'] ) ) {
			return null;
		}
		set_transient( $cache_key, $res['data'], 3 * MINUTE_IN_SECONDS );
		return $res['data'];
	}

	/**
	 * Locate the per-operation config for a provider+currency within active-conf.
	 *
	 * @param array  $conf     active-conf payload.
	 * @param string $provider Provider code.
	 * @param string $currency ISO currency.
	 * @param string $op       Operation type key.
	 * @return array|null Operation config + provider display fields, or null.
	 */
	public function find_operation( $conf, $provider, $currency, $op = 'DEPOSIT' ) {
		if ( ! is_array( $conf ) || empty( $conf['countries'] ) ) {
			return null;
		}
		foreach ( $conf['countries'] as $country ) {
			if ( empty( $country['providers'] ) ) {
				continue;
			}
			foreach ( $country['providers'] as $prov ) {
				if ( ! isset( $prov['provider'] ) || $prov['provider'] !== $provider ) {
					continue;
				}
				if ( empty( $prov['currencies'] ) ) {
					continue;
				}
				foreach ( $prov['currencies'] as $cur ) {
					if ( ! isset( $cur['currency'] ) || $cur['currency'] !== $currency ) {
						continue;
					}
					if ( isset( $cur['operationTypes'][ $op ] ) ) {
						$operation                          = $cur['operationTypes'][ $op ];
						$operation['_provider']             = $provider;
						$operation['_displayName']          = isset( $prov['displayName'] ) ? $prov['displayName'] : $provider;
						$operation['_logo']                 = isset( $prov['logo'] ) ? $prov['logo'] : '';
						$operation['_nameDisplayedToCustomer'] = isset( $prov['nameDisplayedToCustomer'] ) ? $prov['nameDisplayedToCustomer'] : '';
						$operation['_country']              = isset( $country['country'] ) ? $country['country'] : '';
						return $operation;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Read the signatureConfiguration block from active-conf (uncached probe).
	 *
	 * @return array {companyName, signedRequestsOnly, signedCallbacks} or null.
	 */
	public function get_account_config() {
		$res = $this->request( 'GET', '/v2/active-conf' );
		if ( ! $res['ok'] || ! is_array( $res['data'] ) ) {
			return null;
		}
		return $res['data'];
	}

	/**
	 * Public keys for callback verification, keyed by id. Cached 24h.
	 *
	 * @return array Map id => PEM.
	 */
	public function get_public_keys() {
		$cache_key = 'wc_pawapay_pubkeys_' . $this->environment;
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$res = $this->request( 'GET', '/v2/public-key/http' );
		$map = array();
		if ( $res['ok'] && is_array( $res['data'] ) ) {
			foreach ( $res['data'] as $entry ) {
				if ( isset( $entry['id'], $entry['key'] ) ) {
					$map[ $entry['id'] ] = $entry['key'];
				}
			}
			set_transient( $cache_key, $map, DAY_IN_SECONDS );
		}
		return $map;
	}

	/**
	 * Force-refresh the cached public keys (after a verification miss).
	 */
	public function refresh_public_keys() {
		delete_transient( 'wc_pawapay_pubkeys_' . $this->environment );
		return $this->get_public_keys();
	}

	/* ------------------------------------------------------------------ *
	 * Deposits & refunds
	 * ------------------------------------------------------------------ */

	public function create_deposit( $payload ) {
		return $this->request( 'POST', '/v2/deposits', $payload, true );
	}

	public function get_deposit( $deposit_id ) {
		return $this->request( 'GET', '/v2/deposits/' . rawurlencode( $deposit_id ) );
	}

	public function create_refund( $payload ) {
		return $this->request( 'POST', '/v2/refunds', $payload, true );
	}

	public function get_refund( $refund_id ) {
		return $this->request( 'GET', '/v2/refunds/' . rawurlencode( $refund_id ) );
	}

	/**
	 * Pull a customer-safe failure message out of a response.
	 *
	 * @param array  $res      Response envelope.
	 * @param string $fallback Default message.
	 * @return string
	 */
	public function extract_failure_message( $res, $fallback ) {
		if ( isset( $res['data']['failureReason']['failureCode'] ) ) {
			return self::failure_code_to_message( $res['data']['failureReason']['failureCode'], $fallback );
		}
		if ( ! empty( $res['error'] ) ) {
			return $fallback;
		}
		return $fallback;
	}

	/**
	 * Map a pawaPay failure code to a customer-facing message.
	 *
	 * @param string $code     Failure code.
	 * @param string $fallback Default.
	 * @return string
	 */
	public static function failure_code_to_message( $code, $fallback = '' ) {
		$map = array(
			'INSUFFICIENT_BALANCE'             => __( 'Your mobile money wallet does not have enough funds.', 'woocommerce-pawapay' ),
			'PAYER_NOT_FOUND'                  => __( 'This phone number is not registered with the chosen provider.', 'woocommerce-pawapay' ),
			'PAYMENT_NOT_APPROVED'             => __( 'The payment was not authorised in time. Please try again.', 'woocommerce-pawapay' ),
			'PAYER_LIMIT_REACHED'             => __( 'Your mobile money wallet limit has been reached.', 'woocommerce-pawapay' ),
			'PAYMENT_IN_PROGRESS'              => __( 'You have another payment in progress. Please wait a few minutes and try again.', 'woocommerce-pawapay' ),
			'PROVIDER_TEMPORARILY_UNAVAILABLE' => __( 'This mobile money network is temporarily unavailable. Please try again shortly.', 'woocommerce-pawapay' ),
			'INVALID_PHONE_NUMBER'             => __( 'Please enter a valid mobile money phone number.', 'woocommerce-pawapay' ),
			'INVALID_AMOUNT'                   => __( 'The payment amount is not valid for this provider.', 'woocommerce-pawapay' ),
			'AMOUNT_OUT_OF_BOUNDS'             => __( 'The amount is outside the limits allowed by this provider.', 'woocommerce-pawapay' ),
			'INVALID_CURRENCY'                 => __( 'This provider does not support your store currency.', 'woocommerce-pawapay' ),
			'TRANSACTION_ALREADY_IN_PROCESS'   => __( 'Another transaction is already in progress on this wallet. Please wait and retry.', 'woocommerce-pawapay' ),
			'UNSPECIFIED_FAILURE'              => __( 'The mobile money provider could not complete the payment. Please try again.', 'woocommerce-pawapay' ),
		);
		if ( isset( $map[ $code ] ) ) {
			return $map[ $code ];
		}
		return '' !== $fallback ? $fallback : __( 'The payment could not be completed. Please try again.', 'woocommerce-pawapay' );
	}
}
