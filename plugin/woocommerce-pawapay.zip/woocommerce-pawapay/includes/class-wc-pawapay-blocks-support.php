<?php
/**
 * Cart & Checkout Blocks payment method integration.
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class WC_PawaPay_Blocks_Support extends AbstractPaymentMethodType {

	/**
	 * Payment method name (must match the gateway id).
	 *
	 * @var string
	 */
	protected $name = WC_PAWAPAY_GATEWAY_ID;

	/**
	 * Gateway settings.
	 *
	 * @var array
	 */
	protected $settings = array();

	public function initialize() {
		$this->settings = get_option( 'woocommerce_' . WC_PAWAPAY_GATEWAY_ID . '_settings', array() );
	}

	/**
	 * Whether the gateway is available.
	 */
	public function is_active() {
		$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		if ( isset( $gateways[ WC_PAWAPAY_GATEWAY_ID ] ) ) {
			return $gateways[ WC_PAWAPAY_GATEWAY_ID ]->is_available();
		}
		return ! empty( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
	}

	/**
	 * Register and return the block integration script handle(s).
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$handle = 'wc-pawapay-blocks';

		wp_register_script(
			$handle,
			WC_PAWAPAY_PLUGIN_URL . 'assets/js/blocks.js',
			array( 'wc-blocks-registry', 'wp-element', 'wp-html-entities', 'wp-i18n' ),
			WC_PAWAPAY_VERSION,
			true
		);

		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( $handle, 'woocommerce-pawapay' );
		}

		return array( $handle );
	}

	/**
	 * Data passed to the client-side block.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return array(
			'title'         => isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'Mobile Money', 'woocommerce-pawapay' ),
			'description'   => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'supports'      => array( 'products', 'refunds' ),
			'validateUrl'   => rest_url( 'wc-pawapay/v1/validate' ),
			'nonce'         => wp_create_nonce( 'wp_rest' ),
			'allowOverride' => ! isset( $this->settings['allow_provider_override'] ) || 'yes' === $this->settings['allow_provider_override'],
			'i18n'          => array(
				'phoneLabel' => __( 'Mobile money phone number', 'woocommerce-pawapay' ),
				'phonePlaceholder' => __( 'e.g. 0780000000', 'woocommerce-pawapay' ),
				'detecting'  => __( 'Checking number…', 'woocommerce-pawapay' ),
				'detected'   => __( 'Detected provider:', 'woocommerce-pawapay' ),
				'invalid'    => __( 'Enter a valid mobile money number including country code.', 'woocommerce-pawapay' ),
				'required'   => __( 'Please enter your mobile money phone number.', 'woocommerce-pawapay' ),
				'otpLabel'   => __( 'Authorisation code (OTP)', 'woocommerce-pawapay' ),
			),
		);
	}
}
