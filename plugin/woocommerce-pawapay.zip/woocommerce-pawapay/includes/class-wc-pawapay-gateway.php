<?php
/**
 * pawaPay payment gateway (classic checkout + admin + refunds).
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

class WC_PawaPay_Gateway extends WC_Payment_Gateway {

	/** @var string sandbox|production */
	public $environment;

	public function __construct() {
		$this->id                 = WC_PAWAPAY_GATEWAY_ID;
		$this->method_title       = __( 'pawaPay (Mobile Money)', 'woocommerce-pawapay' );
		$this->method_description = __( 'Accept African mobile money payments (MTN MoMo, M-Pesa, Airtel, Orange, Wave and more) directly on your checkout via pawaPay.', 'woocommerce-pawapay' );
		$this->has_fields         = true;
		$this->supports           = array( 'products', 'refunds' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title        = $this->get_option( 'title', __( 'Mobile Money', 'woocommerce-pawapay' ) );
		$this->description  = $this->get_option( 'description', __( 'Pay with mobile money. You will receive a prompt on your phone to authorise the payment.', 'woocommerce-pawapay' ) );
		$this->environment  = $this->get_option( 'environment', 'sandbox' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
	}

	/**
	 * Admin settings.
	 */
	public function init_form_fields() {
		$callback_url = rest_url( 'wc-pawapay/v1/callback' );

		$this->form_fields = array(
			'enabled'                => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-pawapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable pawaPay Mobile Money', 'woocommerce-pawapay' ),
				'default' => 'no',
			),
			'title'                  => array(
				'title'       => __( 'Title', 'woocommerce-pawapay' ),
				'type'        => 'text',
				'description' => __( 'Payment method title shown to customers at checkout.', 'woocommerce-pawapay' ),
				'default'     => __( 'Mobile Money', 'woocommerce-pawapay' ),
				'desc_tip'    => true,
			),
			'description'            => array(
				'title'   => __( 'Description', 'woocommerce-pawapay' ),
				'type'    => 'textarea',
				'default' => __( 'Pay with mobile money. You will receive a prompt on your phone to authorise the payment.', 'woocommerce-pawapay' ),
			),
			'environment'            => array(
				'title'       => __( 'Environment', 'woocommerce-pawapay' ),
				'type'        => 'select',
				'description' => __( 'Use Sandbox for testing and Production for live payments. They use separate tokens and signing keys.', 'woocommerce-pawapay' ),
				'default'     => 'sandbox',
				'desc_tip'    => true,
				'options'     => array(
					'sandbox'    => __( 'Sandbox (testing)', 'woocommerce-pawapay' ),
					'production' => __( 'Production (live)', 'woocommerce-pawapay' ),
				),
			),

			'sandbox_section'        => array(
				'title'       => __( 'Sandbox credentials', 'woocommerce-pawapay' ),
				'type'        => 'title',
				'description' => __( 'From the sandbox dashboard: https://dashboard.sandbox.pawapay.io/', 'woocommerce-pawapay' ),
			),
			'sandbox_api_token'      => array(
				'title' => __( 'Sandbox API token', 'woocommerce-pawapay' ),
				'type'  => 'password',
			),
			'sandbox_key_id'         => array(
				'title'       => __( 'Sandbox signing key ID', 'woocommerce-pawapay' ),
				'type'        => 'text',
				'description' => __( 'Only required if request signing is enabled. Must match the key ID registered in the sandbox dashboard.', 'woocommerce-pawapay' ),
				'desc_tip'    => true,
			),
			'sandbox_private_key'    => array(
				'title'       => __( 'Sandbox private key (PEM)', 'woocommerce-pawapay' ),
				'type'        => 'textarea',
				'description' => __( 'ECDSA P-256 private key in PEM format. Used to sign requests. Leave blank if signing is disabled.', 'woocommerce-pawapay' ),
				'css'         => 'height: 120px; font-family: monospace;',
			),

			'production_section'     => array(
				'title'       => __( 'Production credentials', 'woocommerce-pawapay' ),
				'type'        => 'title',
				'description' => __( 'From the production dashboard: https://dashboard.pawapay.io/', 'woocommerce-pawapay' ),
			),
			'production_api_token'   => array(
				'title' => __( 'Production API token', 'woocommerce-pawapay' ),
				'type'  => 'password',
			),
			'production_key_id'      => array(
				'title' => __( 'Production signing key ID', 'woocommerce-pawapay' ),
				'type'  => 'text',
			),
			'production_private_key' => array(
				'title' => __( 'Production private key (PEM)', 'woocommerce-pawapay' ),
				'type'  => 'textarea',
				'css'   => 'height: 120px; font-family: monospace;',
			),

			'security_section'       => array(
				'title'       => __( 'Security — request signing (optional)', 'woocommerce-pawapay' ),
				'type'        => 'title',
				'description' => __( 'RFC 9421 message signing is <strong>optional</strong>. Leave it off to authenticate with the bearer token only. Turn it on for an extra layer of security — and you <strong>must</strong> turn it on if your pawaPay account has "signed requests only" enabled (otherwise payments are rejected). When enabled, the signing key ID and private key for the selected environment are required.', 'woocommerce-pawapay' ),
			),
			'enable_signing'         => array(
				'title'       => __( 'Sign requests (RFC 9421)', 'woocommerce-pawapay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Sign deposit and refund requests with your private key', 'woocommerce-pawapay' ),
				'description' => __( 'Optional but recommended. When enabled, add the signing key ID and private key for the selected environment below. If the key is missing or invalid, signing is switched back off automatically when you save.', 'woocommerce-pawapay' ),
				'default'     => 'no',
			),
			'verify_callbacks'       => array(
				'title'       => __( 'Verify signed callbacks', 'woocommerce-pawapay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Verify the signature on incoming pawaPay callbacks', 'woocommerce-pawapay' ),
				'description' => __( 'Optional. Enable only if "signed callbacks" is turned on for your pawaPay account. Uses pawaPay\'s published public keys — no extra key needed here.', 'woocommerce-pawapay' ),
				'default'     => 'no',
			),

			'advanced_section'       => array(
				'title'       => __( 'Advanced', 'woocommerce-pawapay' ),
				'type'        => 'title',
				/* translators: %s: callback URL */
				'description' => sprintf(
					__( 'Set this callback URL in your pawaPay dashboard (Settings → System config → Callback URLs) for the DEPOSIT and REFUND operations: <code>%s</code>', 'woocommerce-pawapay' ),
					esc_html( $callback_url )
				),
			),
			'allow_provider_override' => array(
				'title'   => __( 'Allow provider override', 'woocommerce-pawapay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Let customers correct the detected provider at checkout', 'woocommerce-pawapay' ),
				'default' => 'yes',
			),
			'debug'                  => array(
				'title'       => __( 'Debug logging', 'woocommerce-pawapay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Log API requests and callbacks to WooCommerce → Status → Logs', 'woocommerce-pawapay' ),
				'default'     => 'no',
			),
		);
	}

	/**
	 * Get a configured API client for the active environment.
	 *
	 * @return WC_PawaPay_API
	 */
	protected function get_api() {
		return WC_PawaPay_API::from_settings( $this->settings );
	}

	/**
	 * Save settings, then validate the (optional) signing configuration and
	 * surface the account's signing requirements to the admin.
	 *
	 * @return bool
	 */
	public function process_admin_options() {
		$saved = parent::process_admin_options();

		// Reload the freshly-saved values.
		$this->init_settings();
		$this->environment = $this->get_option( 'environment', 'sandbox' );

		// If signing is enabled, the key ID + private key for the active env are required.
		if ( 'yes' === $this->get_option( 'enable_signing' ) ) {
			$env     = $this->environment;
			$key_id  = $this->get_option( $env . '_key_id' );
			$pem     = $this->get_option( $env . '_private_key' );
			$env_lbl = ( 'production' === $env ) ? __( 'production', 'woocommerce-pawapay' ) : __( 'sandbox', 'woocommerce-pawapay' );

			if ( empty( $key_id ) || empty( $pem ) ) {
				$this->update_option( 'enable_signing', 'no' );
				WC_Admin_Settings::add_error(
					/* translators: %s: environment name */
					sprintf( __( 'pawaPay: request signing was turned back OFF because the %s signing key ID and/or private key are missing.', 'woocommerce-pawapay' ), $env_lbl )
				);
			} elseif ( ! function_exists( 'openssl_pkey_get_private' ) || false === openssl_pkey_get_private( $pem ) ) {
				$this->update_option( 'enable_signing', 'no' );
				WC_Admin_Settings::add_error(
					__( 'pawaPay: request signing was turned back OFF because the private key could not be parsed. Paste a valid ECDSA P-256 PEM key.', 'woocommerce-pawapay' )
				);
			}
		}

		// Best-effort: tell the admin what the account itself requires.
		$this->report_account_signature_requirements();

		return $saved;
	}

	/**
	 * Probe active-conf and warn if the account's signing requirements don't
	 * match the configured options. Non-fatal; skipped silently if unreachable.
	 */
	protected function report_account_signature_requirements() {
		$api  = WC_PawaPay_API::from_settings( $this->settings );
		$conf = $api->get_account_config();
		if ( ! is_array( $conf ) ) {
			return; // No token yet, or network/auth issue — don't block saving.
		}

		if ( ! empty( $conf['companyName'] ) ) {
			WC_Admin_Settings::add_message(
				/* translators: %s: pawaPay company name */
				sprintf( __( 'pawaPay connected successfully as "%s".', 'woocommerce-pawapay' ), $conf['companyName'] )
			);
		}

		$sig = isset( $conf['signatureConfiguration'] ) ? $conf['signatureConfiguration'] : array();

		if ( ! empty( $sig['signedRequestsOnly'] ) && 'yes' !== $this->get_option( 'enable_signing' ) ) {
			WC_Admin_Settings::add_error(
				__( 'pawaPay: your account requires signed requests (signedRequestsOnly), but request signing is disabled. Deposits and refunds will be rejected until you enable signing and add a valid key.', 'woocommerce-pawapay' )
			);
		}

		if ( ! empty( $sig['signedCallbacks'] ) && 'yes' !== $this->get_option( 'verify_callbacks' ) ) {
			WC_Admin_Settings::add_message(
				__( 'pawaPay: your account sends signed callbacks. Consider enabling "Verify signed callbacks" for added security.', 'woocommerce-pawapay' )
			);
		}
	}

	/**
	 * Availability: enabled + token present for the active environment.
	 */
	public function is_available() {
		if ( 'yes' !== $this->enabled ) {
			return false;
		}
		$token = ( 'production' === $this->environment )
			? $this->get_option( 'production_api_token' )
			: $this->get_option( 'sandbox_api_token' );
		if ( empty( $token ) ) {
			return false;
		}
		return parent::is_available();
	}

	/**
	 * Enqueue checkout / order-received scripts.
	 */
	public function payment_scripts() {
		if ( 'yes' !== $this->enabled ) {
			return;
		}

		$is_checkout       = is_checkout() && ! is_order_received_page();
		$is_order_received = is_order_received_page();

		if ( ! $is_checkout && ! $is_order_received ) {
			return;
		}

		wp_register_script(
			'wc-pawapay-checkout',
			WC_PAWAPAY_PLUGIN_URL . 'assets/js/checkout.js',
			array( 'jquery' ),
			WC_PAWAPAY_VERSION,
			true
		);
		wp_register_style(
			'wc-pawapay',
			WC_PAWAPAY_PLUGIN_URL . 'assets/css/pawapay.css',
			array(),
			WC_PAWAPAY_VERSION
		);

		$data = array(
			'validateUrl' => rest_url( 'wc-pawapay/v1/validate' ),
			'statusUrl'   => rest_url( 'wc-pawapay/v1/status' ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'gatewayId'   => $this->id,
			'allowOverride' => 'yes' === $this->get_option( 'allow_provider_override', 'yes' ),
			'i18n'        => array(
				'detecting'   => __( 'Checking number…', 'woocommerce-pawapay' ),
				'invalid'     => __( 'Enter a valid mobile money number including country code.', 'woocommerce-pawapay' ),
				'detected'    => __( 'Detected provider:', 'woocommerce-pawapay' ),
				'waiting'     => __( 'Check your phone and enter your mobile money PIN to authorise the payment…', 'woocommerce-pawapay' ),
				'enqueued'    => __( 'The network is busy — we will complete your payment as soon as it is back up.', 'woocommerce-pawapay' ),
				'reconciling' => __( 'Confirming your payment…', 'woocommerce-pawapay' ),
				'completed'   => __( 'Payment received. Thank you!', 'woocommerce-pawapay' ),
				'failed'      => __( 'Payment failed.', 'woocommerce-pawapay' ),
				'otpLabel'    => __( 'Authorisation code (OTP)', 'woocommerce-pawapay' ),
			),
		);

		if ( $is_order_received ) {
			$order_id = absint( get_query_var( 'order-received' ) );
			$order    = $order_id ? wc_get_order( $order_id ) : false;
			if ( $order && $order->get_payment_method() === $this->id ) {
				$data['orderId']  = $order_id;
				$data['orderKey'] = $order->get_order_key();
				$data['poll']     = true;
			}
		}

		wp_localize_script( 'wc-pawapay-checkout', 'wcPawaPay', $data );
		wp_enqueue_script( 'wc-pawapay-checkout' );
		wp_enqueue_style( 'wc-pawapay' );
	}

	/**
	 * Classic checkout payment fields.
	 */
	public function payment_fields() {
		if ( $this->description ) {
			echo wpautop( wp_kses_post( $this->description ) );
		}
		$placeholder = esc_attr__( 'e.g. 0780000000', 'woocommerce-pawapay' );
		?>
		<div class="wc-pawapay-fields">
			<p class="form-row form-row-wide">
				<label for="pawapay_phone"><?php esc_html_e( 'Mobile money phone number', 'woocommerce-pawapay' ); ?> <span class="required">*</span></label>
				<input id="pawapay_phone" name="pawapay_phone" type="tel" autocomplete="tel"
					inputmode="tel" class="input-text" placeholder="<?php echo $placeholder; ?>" />
			</p>
			<input type="hidden" id="pawapay_provider" name="pawapay_provider" value="" />
			<div class="wc-pawapay-provider-info" id="pawapay_provider_info" aria-live="polite"></div>
			<p class="form-row form-row-wide wc-pawapay-otp-row" id="pawapay_otp_row" style="display:none;">
				<label for="pawapay_otp"><?php esc_html_e( 'Authorisation code (OTP)', 'woocommerce-pawapay' ); ?></label>
				<input id="pawapay_otp" name="pawapay_otp" type="text" inputmode="numeric" class="input-text" />
				<span class="wc-pawapay-otp-help" id="pawapay_otp_help"></span>
			</p>
		</div>
		<?php
	}

	/**
	 * Validate the classic checkout fields before order creation.
	 */
	public function validate_fields() {
		if ( empty( $_POST['pawapay_phone'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			wc_add_notice( __( 'Please enter your mobile money phone number.', 'woocommerce-pawapay' ), 'error' );
			return false;
		}
		return true;
	}

	/**
	 * Process the payment: predict provider, validate, initiate the deposit.
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the checkout nonce upstream.
		$phone_raw     = isset( $_POST['pawapay_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['pawapay_phone'] ) ) : '';
		$provider_post = isset( $_POST['pawapay_provider'] ) ? sanitize_text_field( wp_unslash( $_POST['pawapay_provider'] ) ) : '';
		$otp           = isset( $_POST['pawapay_otp'] ) ? sanitize_text_field( wp_unslash( $_POST['pawapay_otp'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $phone_raw ) {
			wc_add_notice( __( 'Please enter your mobile money phone number.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}

		$api = $this->get_api();

		// 1. Sanitise + predict provider.
		$pred = $api->predict_provider( $phone_raw );
		if ( ! $pred['ok'] ) {
			wc_add_notice( $pred['error'], 'error' );
			return array( 'result' => 'failure' );
		}
		$msisdn   = $pred['phoneNumber'];
		$country  = $pred['country'];
		$provider = $pred['provider'];

		// Allow a customer-confirmed override from the UI.
		if ( 'yes' === $this->get_option( 'allow_provider_override', 'yes' ) && '' !== $provider_post ) {
			$provider = $provider_post;
		}

		$currency = $order->get_currency();

		// 2. Look up provider config (limits, decimals, auth type, availability).
		$conf = $api->get_active_conf( $country, 'DEPOSIT' );
		$op   = $conf ? $api->find_operation( $conf, $provider, $currency, 'DEPOSIT' ) : null;
		if ( ! $op ) {
			wc_add_notice(
				/* translators: %s: store currency */
				sprintf( __( 'Mobile money is not available for this number with the %s currency. Please try a different number or payment method.', 'woocommerce-pawapay' ), esc_html( $currency ) ),
				'error'
			);
			return array( 'result' => 'failure' );
		}
		if ( isset( $op['status'] ) && 'OPERATIONAL' !== $op['status'] ) {
			wc_add_notice( __( 'This mobile money network is temporarily unavailable. Please try again shortly.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}

		// 3. Format amount to the provider's decimal rules + bounds check.
		$decimals = ( isset( $op['decimalsInAmount'] ) && 'TWO_PLACES' === $op['decimalsInAmount'] ) ? 2 : 0;
		$amount   = number_format( (float) $order->get_total(), $decimals, '.', '' );

		if ( isset( $op['minAmount'] ) && (float) $amount < (float) $op['minAmount'] ) {
			wc_add_notice( __( 'Your order total is below the minimum allowed for this mobile money provider.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}
		if ( isset( $op['maxAmount'] ) && (float) $amount > (float) $op['maxAmount'] ) {
			wc_add_notice( __( 'Your order total is above the maximum allowed for this mobile money provider.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}

		$auth_type = isset( $op['authType'] ) ? $op['authType'] : 'PROVIDER_AUTH';
		if ( 'PREAUTH' === $auth_type && '' === $otp ) {
			wc_add_notice( __( 'Please enter the authorisation code (OTP) generated from your mobile money menu.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}

		// 4. Generate + persist the depositId BEFORE the API call (idempotency anchor).
		$deposit_id = wp_generate_uuid4();
		$order->update_meta_data( '_pawapay_deposit_id', $deposit_id );
		$order->update_meta_data( '_pawapay_provider', $provider );
		$order->update_meta_data( '_pawapay_environment', $api->get_environment() );
		$order->update_meta_data( '_pawapay_auth_type', $auth_type );
		$order->update_meta_data( '_pawapay_state', 'PENDING' );
		$order->update_meta_data( '_pawapay_initiated', time() );
		$order->update_status( 'pending', __( 'Awaiting pawaPay mobile money authorisation.', 'woocommerce-pawapay' ) );
		$order->save();

		// 5. Build the deposit payload.
		$payload = array(
			'depositId'         => $deposit_id,
			'amount'            => $amount,
			'currency'          => $currency,
			'payer'             => array(
				'type'           => 'MMO',
				'accountDetails' => array(
					'phoneNumber' => $msisdn,
					'provider'    => $provider,
				),
			),
			'customerMessage'   => $this->build_customer_message( $order ),
			'clientReferenceId' => $order->get_order_number(),
			'metadata'          => array(
				array( 'orderId' => (string) $order->get_id() ),
			),
		);

		if ( 'PREAUTH' === $auth_type ) {
			$payload['preAuthorisationCode'] = $otp;
		}
		if ( 'REDIRECT_AUTH' === $auth_type ) {
			$payload['successfulUrl'] = $this->get_return_url( $order );
			$payload['failedUrl']     = $order->get_checkout_payment_url( false );
		}

		// 6. Initiate.
		$res = $api->create_deposit( $payload );

		// Transport error / timeout: do NOT assume failure — verify via status-check.
		if ( ! $res['ok'] && ! empty( $res['transport'] ) ) {
			return $this->verify_and_redirect( $api, $order, $deposit_id );
		}

		$data   = is_array( $res['data'] ) ? $res['data'] : array();
		$status = isset( $data['status'] ) ? $data['status'] : '';

		if ( 'ACCEPTED' === $status ) {
			$order->add_order_note( __( 'pawaPay deposit accepted; awaiting customer authorisation.', 'woocommerce-pawapay' ) );
			$order->save();
			WC()->cart->empty_cart();
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $order ),
			);
		}

		if ( 'DUPLICATE_IGNORED' === $status ) {
			return $this->verify_and_redirect( $api, $order, $deposit_id );
		}

		if ( 'REJECTED' === $status ) {
			$message = $api->extract_failure_message( $res, __( 'The payment could not be started. Please try again.', 'woocommerce-pawapay' ) );
			$order->update_meta_data( '_pawapay_state', 'FAILED' );
			$order->update_status( 'failed', $message );
			$order->save();
			wc_add_notice( $message, 'error' );
			return array( 'result' => 'failure' );
		}

		// Anything else (UNKNOWN_ERROR / unexpected): verify, don't fail blindly.
		return $this->verify_and_redirect( $api, $order, $deposit_id );
	}

	/**
	 * On ambiguous initiation, call status-check before deciding.
	 *
	 * @param WC_PawaPay_API $api        API client.
	 * @param WC_Order       $order      Order.
	 * @param string         $deposit_id Deposit ID.
	 * @return array
	 */
	protected function verify_and_redirect( $api, $order, $deposit_id ) {
		$res = $api->get_deposit( $deposit_id );
		if ( $res['ok'] && isset( $res['data']['status'] ) && 'NOT_FOUND' === $res['data']['status'] ) {
			// Only mark failed if it genuinely never reached pawaPay.
			$order->update_meta_data( '_pawapay_state', 'FAILED' );
			$order->update_status( 'failed', __( 'pawaPay never received the deposit request.', 'woocommerce-pawapay' ) );
			$order->save();
			wc_add_notice( __( 'We could not reach the payment provider. Please try again.', 'woocommerce-pawapay' ), 'error' );
			return array( 'result' => 'failure' );
		}

		// FOUND or unknown — leave pending and let the customer wait / reconciler resolve.
		$order->add_order_note( __( 'pawaPay deposit pending (verified via status-check after ambiguous initiation).', 'woocommerce-pawapay' ) );
		$order->save();
		WC()->cart->empty_cart();
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Process a refund (full or partial) via pawaPay.
	 *
	 * Note: refunds are asynchronous. We return true on ACCEPTED and confirm
	 * the final state via the refund callback (an order note is added then).
	 *
	 * @param int    $order_id Order ID.
	 * @param float  $amount   Amount, or null for full.
	 * @param string $reason   Reason.
	 * @return bool|WP_Error
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_Error( 'pawapay_refund', __( 'Order not found.', 'woocommerce-pawapay' ) );
		}

		$deposit_id = $order->get_meta( '_pawapay_deposit_id' );
		if ( empty( $deposit_id ) ) {
			return new WP_Error( 'pawapay_refund', __( 'This order has no pawaPay deposit to refund.', 'woocommerce-pawapay' ) );
		}
		if ( $order->get_meta( '_pawapay_state' ) !== 'COMPLETED' ) {
			return new WP_Error( 'pawapay_refund', __( 'Only completed pawaPay payments can be refunded.', 'woocommerce-pawapay' ) );
		}

		$api       = $this->get_api();
		$refund_id = wp_generate_uuid4();

		$payload = array(
			'refundId'  => $refund_id,
			'depositId' => $deposit_id,
		);

		// Partial refund: include amount + currency (full refund omits amount).
		$order_total = (float) $order->get_total();
		if ( null !== $amount && (float) $amount > 0 && (float) $amount < $order_total ) {
			$decimals            = $this->deposit_decimals( $order );
			$payload['amount']   = number_format( (float) $amount, $decimals, '.', '' );
			$payload['currency'] = $order->get_currency();
		}
		if ( ! empty( $reason ) ) {
			$payload['metadata'] = array( array( 'reason' => substr( sanitize_text_field( $reason ), 0, 100 ) ) );
		}

		// Track refund ids so callbacks can be matched back to the order.
		$refunds = (array) $order->get_meta( '_pawapay_refund_ids' );
		$refunds[] = $refund_id;
		$order->update_meta_data( '_pawapay_refund_ids', array_values( array_unique( $refunds ) ) );
		$order->save();

		$res = $api->create_refund( $payload );

		if ( ! $res['ok'] && ! empty( $res['transport'] ) ) {
			// Unknown — verify.
			$check = $api->get_refund( $refund_id );
			if ( $check['ok'] && isset( $check['data']['status'] ) && 'NOT_FOUND' === $check['data']['status'] ) {
				return new WP_Error( 'pawapay_refund', __( 'The refund request did not reach pawaPay. Please try again.', 'woocommerce-pawapay' ) );
			}
			$order->add_order_note( __( 'pawaPay refund submitted (status unconfirmed); will reconcile via callback.', 'woocommerce-pawapay' ) );
			return true;
		}

		$data   = is_array( $res['data'] ) ? $res['data'] : array();
		$status = isset( $data['status'] ) ? $data['status'] : '';

		if ( 'ACCEPTED' === $status || 'DUPLICATE_IGNORED' === $status ) {
			$order->add_order_note(
				/* translators: %s: refund id */
				sprintf( __( 'pawaPay refund initiated (refundId %s). Awaiting confirmation callback.', 'woocommerce-pawapay' ), $refund_id )
			);
			return true;
		}

		$message = $api->extract_failure_message( $res, __( 'The refund was rejected by pawaPay.', 'woocommerce-pawapay' ) );
		return new WP_Error( 'pawapay_refund', $message );
	}

	/**
	 * Decimal places for the order's deposit provider (best effort).
	 *
	 * @param WC_Order $order Order.
	 * @return int
	 */
	protected function deposit_decimals( $order ) {
		$provider = $order->get_meta( '_pawapay_provider' );
		$api      = $this->get_api();
		$conf     = $api->get_active_conf( '', 'REFUND' );
		if ( $conf && $provider ) {
			$op = $api->find_operation( $conf, $provider, $order->get_currency(), 'REFUND' );
			if ( $op && isset( $op['decimalsInAmount'] ) ) {
				return 'TWO_PLACES' === $op['decimalsInAmount'] ? 2 : 0;
			}
		}
		return wc_get_price_decimals();
	}

	/**
	 * Build a pawaPay customerMessage (4-22 chars, [a-zA-Z0-9 ]).
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	protected function build_customer_message( $order ) {
		$raw = 'Order ' . $order->get_order_number();
		$msg = preg_replace( '/[^a-zA-Z0-9 ]/', '', $raw );
		$msg = trim( preg_replace( '/\s+/', ' ', $msg ) );
		if ( strlen( $msg ) > 22 ) {
			$msg = substr( $msg, 0, 22 );
		}
		if ( strlen( $msg ) < 4 ) {
			$msg = 'Order ' . wp_rand( 1000, 9999 );
		}
		return $msg;
	}
}
