<?php
/**
 * Lightweight logger wrapper around WooCommerce's logging system.
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

class WC_PawaPay_Logger {

	const SOURCE = 'pawapay';

	/**
	 * Whether debug logging is enabled (read from gateway settings).
	 *
	 * @var bool|null
	 */
	protected static $enabled = null;

	/**
	 * Resolve whether debug logging is on.
	 */
	protected static function enabled() {
		if ( null === self::$enabled ) {
			$settings      = get_option( 'woocommerce_' . WC_PAWAPAY_GATEWAY_ID . '_settings', array() );
			self::$enabled = is_array( $settings ) && isset( $settings['debug'] ) && 'yes' === $settings['debug'];
		}
		return self::$enabled;
	}

	/**
	 * Log a debug message. Sensitive values must be redacted by the caller.
	 *
	 * @param string $message Message.
	 * @param string $level   PSR-3 level.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( ! self::enabled() && 'error' !== $level ) {
			return;
		}
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}
		$logger = wc_get_logger();
		$logger->log( $level, $message, array( 'source' => self::SOURCE ) );
	}

	/**
	 * Convenience error logger (always recorded).
	 *
	 * @param string $message Message.
	 */
	public static function error( $message ) {
		self::log( $message, 'error' );
	}
}
