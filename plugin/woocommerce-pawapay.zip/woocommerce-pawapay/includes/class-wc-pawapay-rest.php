<?php
/**
 * REST endpoints: callback receiver, status poller, phone validation proxy,
 * plus the reconciliation cron worker.
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

class WC_PawaPay_REST {

	const REST_NS = 'wc-pawapay/v1';

	/** @var WC_PawaPay_REST */
	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		register_rest_route(
			self::REST_NS,
			'/callback',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_callback' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::REST_NS,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_status' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'order_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
					'key'      => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);

		register_rest_route(
			self::REST_NS,
			'/validate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_validate' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'phone' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Settings helpers
	 * ------------------------------------------------------------------ */

	protected function settings() {
		return get_option( 'woocommerce_' . WC_PAWAPAY_GATEWAY_ID . '_settings', array() );
	}

	protected function verify_callbacks_enabled() {
		$s = $this->settings();
		return isset( $s['verify_callbacks'] ) && 'yes' === $s['verify_callbacks'];
	}

	/* ------------------------------------------------------------------ *
	 * Callback receiver
	 * ------------------------------------------------------------------ */

	/**
	 * Handle an inbound pawaPay callback (deposit or refund).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_callback( WP_REST_Request $request ) {
		$raw = $request->get_body();

		// Verify signature when enabled.
		if ( $this->verify_callbacks_enabled() ) {
			$verified = $this->verify_callback_signature( $request, $raw );
			if ( is_wp_error( $verified ) ) {
				WC_PawaPay_Logger::error( 'Callback signature rejected: ' . $verified->get_error_message() );
				return new WP_REST_Response( array( 'error' => 'invalid signature' ), 401 );
			}
		}

		$payload = json_decode( $raw, true );
		if ( ! is_array( $payload ) ) {
			return new WP_REST_Response( array( 'error' => 'invalid body' ), 400 );
		}

		// Deposit callback.
		if ( ! empty( $payload['depositId'] ) ) {
			$order = $this->find_order_by_meta( '_pawapay_deposit_id', $payload['depositId'] );
			if ( ! $order ) {
				WC_PawaPay_Logger::error( 'Deposit callback for unknown depositId ' . $payload['depositId'] );
				return new WP_REST_Response( array( 'ok' => true ), 200 ); // ack; nothing to do.
			}
			$this->apply_deposit_status( $order, $payload );
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}

		// Refund callback.
		if ( ! empty( $payload['refundId'] ) ) {
			$order = $this->find_order_by_refund( $payload['refundId'] );
			if ( ! $order ) {
				return new WP_REST_Response( array( 'ok' => true ), 200 );
			}
			$this->apply_refund_status( $order, $payload );
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * Verify the RFC 9421 signature on a callback request.
	 *
	 * @param WP_REST_Request $request Request.
	 * @param string          $raw     Raw body.
	 * @return true|WP_Error
	 */
	protected function verify_callback_signature( WP_REST_Request $request, $raw ) {
		$api  = WC_PawaPay_API::from_settings( $this->settings() );
		$keys = $api->get_public_keys();
		if ( empty( $keys ) ) {
			return new WP_Error( 'pawapay_no_keys', 'No public keys available for verification' );
		}

		$headers = array(
			'signature-input' => (string) $request->get_header( 'signature-input' ),
			'signature'       => (string) $request->get_header( 'signature' ),
			'content-digest'  => (string) $request->get_header( 'content-digest' ),
			'signature-date'  => (string) $request->get_header( 'signature-date' ),
			'content-type'    => (string) $request->get_header( 'content-type' ),
		);

		$authority = (string) $request->get_header( 'host' );
		$path      = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );

		$result = WC_PawaPay_Signer::verify_callback( 'POST', $authority, $path, $headers, $raw, $keys );

		// One retry with refreshed keys (key rotation).
		if ( is_wp_error( $result ) && 'pawapay_unknown_keyid' === $result->get_error_code() ) {
			$keys   = $api->refresh_public_keys();
			$result = WC_PawaPay_Signer::verify_callback( 'POST', $authority, $path, $headers, $raw, $keys );
		}

		return $result;
	}

	/* ------------------------------------------------------------------ *
	 * Status poller (customer waiting page)
	 * ------------------------------------------------------------------ */

	/**
	 * Return the current payment state for the order-received waiting screen.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_status( WP_REST_Request $request ) {
		$order_id = absint( $request->get_param( 'order_id' ) );
		$key      = sanitize_text_field( $request->get_param( 'key' ) );
		$order    = wc_get_order( $order_id );

		if ( ! $order || ! hash_equals( $order->get_order_key(), $key ) ) {
			return new WP_REST_Response( array( 'error' => 'not found' ), 404 );
		}

		$deposit_id = $order->get_meta( '_pawapay_deposit_id' );
		$state      = $order->get_meta( '_pawapay_state' );

		// While pending, throttle a live status-check (acts as a per-customer reconciler).
		if ( $deposit_id && in_array( $state, array( 'PENDING', '' ), true ) ) {
			$last = (int) $order->get_meta( '_pawapay_last_poll' );
			if ( ( time() - $last ) >= 4 ) {
				$api = WC_PawaPay_API::from_settings( $this->settings() );
				$res = $api->get_deposit( $deposit_id );
				$order->update_meta_data( '_pawapay_last_poll', time() );
				$order->save();
				if ( $res['ok'] && isset( $res['data']['status'] ) && 'FOUND' === $res['data']['status'] && isset( $res['data']['data'] ) ) {
					$this->apply_deposit_status( $order, $res['data']['data'] );
					$order = wc_get_order( $order_id ); // reload.
				}
			}
		}

		$state            = $order->get_meta( '_pawapay_state' );
		$lifecycle        = $order->get_meta( '_pawapay_lifecycle' );
		$authorization_url = $order->get_meta( '_pawapay_authorization_url' );

		$response = array(
			'state'     => $state ? $state : 'PENDING',
			'lifecycle' => $lifecycle ? $lifecycle : '',
		);

		if ( 'COMPLETED' === $state ) {
			$response['redirect'] = $this->return_url_for( $order );
		} elseif ( 'FAILED' === $state ) {
			$response['failureMessage'] = $order->get_meta( '_pawapay_failure_message' );
		} elseif ( $authorization_url ) {
			$response['authorizationUrl'] = $authorization_url;
		}

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * Resolve the order-received URL.
	 */
	protected function return_url_for( $order ) {
		$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		if ( isset( $gateways[ WC_PAWAPAY_GATEWAY_ID ] ) ) {
			return $gateways[ WC_PAWAPAY_GATEWAY_ID ]->get_return_url( $order );
		}
		return $order->get_checkout_order_received_url();
	}

	/* ------------------------------------------------------------------ *
	 * Phone validation proxy (checkout UX)
	 * ------------------------------------------------------------------ */

	/**
	 * Predict the provider for a phone number and return display + auth info.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle_validate( WP_REST_Request $request ) {
		$phone = sanitize_text_field( $request->get_param( 'phone' ) );
		if ( '' === $phone ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'missing phone' ), 200 );
		}

		$api  = WC_PawaPay_API::from_settings( $this->settings() );
		$pred = $api->predict_provider( $phone );
		if ( ! $pred['ok'] ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $pred['error'] ), 200 );
		}

		$currency = get_woocommerce_currency();
		$conf     = $api->get_active_conf( $pred['country'], 'DEPOSIT' );
		$op       = $conf ? $api->find_operation( $conf, $pred['provider'], $currency, 'DEPOSIT' ) : null;

		$out = array(
			'ok'       => true,
			'provider' => $pred['provider'],
			'country'  => $pred['country'],
		);

		if ( $op ) {
			$out['displayName']             = $op['_displayName'];
			$out['logo']                    = $op['_logo'];
			$out['nameDisplayedToCustomer'] = $op['_nameDisplayedToCustomer'];
			$out['authType']                = isset( $op['authType'] ) ? $op['authType'] : 'PROVIDER_AUTH';
			$out['status']                  = isset( $op['status'] ) ? $op['status'] : 'OPERATIONAL';
			$out['supported']               = true;
			if ( isset( $op['authTokenInstructions'] ) ) {
				$out['authTokenInstructions'] = $op['authTokenInstructions'];
			}
		} else {
			$out['supported'] = false;
		}

		return new WP_REST_Response( $out, 200 );
	}

	/* ------------------------------------------------------------------ *
	 * Status application
	 * ------------------------------------------------------------------ */

	/**
	 * Apply a deposit status (from callback or status-check) to an order.
	 *
	 * @param WC_Order $order   Order.
	 * @param array    $payload Deposit data ({status, providerTransactionId, failureReason,...}).
	 */
	public function apply_deposit_status( $order, $payload ) {
		$status = isset( $payload['status'] ) ? $payload['status'] : '';
		if ( '' === $status ) {
			return;
		}

		$order->update_meta_data( '_pawapay_lifecycle', $status );

		// Idempotency: ignore repeat terminal callbacks.
		$current = $order->get_meta( '_pawapay_state' );
		if ( 'COMPLETED' === $current || 'FAILED' === $current ) {
			$order->save();
			return;
		}

		switch ( $status ) {
			case 'COMPLETED':
				$txn = isset( $payload['providerTransactionId'] ) ? $payload['providerTransactionId'] : '';
				$order->update_meta_data( '_pawapay_state', 'COMPLETED' );
				if ( ! $order->is_paid() ) {
					$order->payment_complete( $txn );
				}
				$order->add_order_note(
					/* translators: %s: provider transaction id */
					sprintf( __( 'pawaPay payment completed. Provider transaction: %s', 'woocommerce-pawapay' ), $txn ? $txn : '—' )
				);
				break;

			case 'FAILED':
				$code    = isset( $payload['failureReason']['failureCode'] ) ? $payload['failureReason']['failureCode'] : '';
				$message = WC_PawaPay_API::failure_code_to_message( $code, __( 'Payment failed.', 'woocommerce-pawapay' ) );
				$order->update_meta_data( '_pawapay_state', 'FAILED' );
				$order->update_meta_data( '_pawapay_failure_message', $message );
				$order->update_status( 'failed', sprintf( 'pawaPay: %s (%s)', $message, $code ? $code : 'no code' ) );
				break;

			case 'PROCESSING':
				// REDIRECT_AUTH: the authorization URL is ready.
				if ( ! empty( $payload['authorizationUrl'] ) ) {
					$order->update_meta_data( '_pawapay_authorization_url', esc_url_raw( $payload['authorizationUrl'] ) );
					$order->add_order_note( __( 'pawaPay: redirecting customer to provider authorisation page.', 'woocommerce-pawapay' ) );
				}
				$order->update_meta_data( '_pawapay_state', 'PENDING' );
				break;

			case 'ENQUEUED':
			case 'ACCEPTED':
			case 'IN_RECONCILIATION':
				$order->update_meta_data( '_pawapay_state', 'PENDING' );
				break;

			default:
				$order->update_meta_data( '_pawapay_state', 'PENDING' );
				$order->add_order_note(
					/* translators: %s: status */
					sprintf( __( 'pawaPay: unexpected status "%s" — needs attention.', 'woocommerce-pawapay' ), $status )
				);
				break;
		}

		$order->save();
	}

	/**
	 * Apply a refund status to an order (note-only; refund already recorded in WC).
	 *
	 * @param WC_Order $order   Order.
	 * @param array    $payload Refund data.
	 */
	public function apply_refund_status( $order, $payload ) {
		$status   = isset( $payload['status'] ) ? $payload['status'] : '';
		$refund_id = isset( $payload['refundId'] ) ? $payload['refundId'] : '';

		if ( 'COMPLETED' === $status ) {
			$order->add_order_note(
				/* translators: %s: refund id */
				sprintf( __( 'pawaPay refund %s completed.', 'woocommerce-pawapay' ), $refund_id )
			);
		} elseif ( 'FAILED' === $status ) {
			$code = isset( $payload['failureReason']['failureCode'] ) ? $payload['failureReason']['failureCode'] : 'unknown';
			$order->add_order_note(
				/* translators: 1: refund id, 2: failure code */
				sprintf( __( 'pawaPay refund %1$s FAILED (%2$s). The WooCommerce refund record may need to be reviewed manually.', 'woocommerce-pawapay' ), $refund_id, $code )
			);
		}
		$order->save();
	}

	/* ------------------------------------------------------------------ *
	 * Order lookup helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Find a single order by a meta key/value (HPOS-compatible).
	 *
	 * @param string $key   Meta key.
	 * @param string $value Meta value.
	 * @return WC_Order|false
	 */
	protected function find_order_by_meta( $key, $value ) {
		$orders = wc_get_orders(
			array(
				'limit'      => 1,
				'meta_query' => array(
					array(
						'key'   => $key,
						'value' => $value,
					),
				),
			)
		);
		return ! empty( $orders ) ? $orders[0] : false;
	}

	/**
	 * Find an order that issued a given refundId.
	 *
	 * @param string $refund_id Refund ID.
	 * @return WC_Order|false
	 */
	protected function find_order_by_refund( $refund_id ) {
		$orders = wc_get_orders(
			array(
				'limit'      => 1,
				'meta_query' => array(
					array(
						'key'     => '_pawapay_refund_ids',
						'value'   => $refund_id,
						'compare' => 'LIKE',
					),
				),
			)
		);
		return ! empty( $orders ) ? $orders[0] : false;
	}

	/* ------------------------------------------------------------------ *
	 * Reconciliation cron
	 * ------------------------------------------------------------------ */

	/**
	 * Resolve orders that have been pending longer than 15 minutes.
	 */
	public static function reconcile_pending_orders() {
		$self = self::instance();
		$api  = WC_PawaPay_API::from_settings( $self->settings() );

		$orders = wc_get_orders(
			array(
				'limit'        => 50,
				'status'       => array( 'pending', 'on-hold' ),
				'payment_method' => WC_PAWAPAY_GATEWAY_ID,
				'meta_query'   => array(
					array(
						'key'     => '_pawapay_state',
						'value'   => 'PENDING',
					),
				),
			)
		);

		foreach ( $orders as $order ) {
			$initiated = (int) $order->get_meta( '_pawapay_initiated' );
			if ( $initiated && ( time() - $initiated ) < 15 * MINUTE_IN_SECONDS ) {
				continue; // Too fresh; leave for callbacks.
			}
			$deposit_id = $order->get_meta( '_pawapay_deposit_id' );
			if ( empty( $deposit_id ) ) {
				continue;
			}

			$res = $api->get_deposit( $deposit_id );
			if ( ! $res['ok'] || ! isset( $res['data']['status'] ) ) {
				continue; // Leave for next cycle.
			}

			if ( 'FOUND' === $res['data']['status'] && isset( $res['data']['data'] ) ) {
				$self->apply_deposit_status( $order, $res['data']['data'] );
			} elseif ( 'NOT_FOUND' === $res['data']['status'] ) {
				$order->update_meta_data( '_pawapay_state', 'FAILED' );
				$order->update_meta_data( '_pawapay_failure_message', __( 'Payment was never received by pawaPay.', 'woocommerce-pawapay' ) );
				$order->update_status( 'failed', __( 'pawaPay: deposit not found after reconciliation window.', 'woocommerce-pawapay' ) );
				$order->save();
			}
		}
	}
}
