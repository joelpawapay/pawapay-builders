<?php
/**
 * RFC 9421 HTTP Message Signatures for the pawaPay Merchant API v2.
 *
 * Signing: ECDSA P-256 over the signature base (SHA-256), SHA-512 Content-Digest.
 * pawaPay expects the IEEE-P1363 (raw r||s) signature encoding, not DER — PHP's
 * openssl_sign() emits DER, so we convert in both directions.
 *
 * Ported from the pawaPay skill reference implementation (scripts/sign_request.js).
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

class WC_PawaPay_Signer {

	const ACCEPT_SIGNATURE = 'rsa-pss-sha512,ecdsa-p256-sha256,rsa-v1_5-sha256,ecdsa-p384-sha384';
	const ACCEPT_DIGEST    = 'sha-256,sha-512';
	const ALGORITHM        = 'ecdsa-p256-sha256';
	const DIGEST_ALGORITHM = 'sha-512';
	const CONTENT_TYPE     = 'application/json; charset=UTF-8';
	const LIFETIME_SECONDS = 60;

	/**
	 * Covered components, in order. Must match the Signature-Input list exactly.
	 */
	const COVERED = array( '@method', '@authority', '@path', 'signature-date', 'content-digest', 'content-type' );

	/**
	 * Sign an outbound request and return the headers to attach.
	 *
	 * @param string $method        HTTP method.
	 * @param string $authority     Host (e.g. api.sandbox.pawapay.io).
	 * @param string $path          Path only (e.g. /v2/deposits).
	 * @param string $body_bytes    The EXACT JSON bytes that will be sent.
	 * @param string $private_pem   PEM-encoded EC private key.
	 * @param string $key_id        Registered key id (Dashboard).
	 * @return array|WP_Error Header map, or WP_Error on failure.
	 */
	public static function sign_request( $method, $authority, $path, $body_bytes, $private_pem, $key_id ) {
		$key = openssl_pkey_get_private( $private_pem );
		if ( false === $key ) {
			return new WP_Error( 'pawapay_bad_key', __( 'pawaPay signing private key could not be loaded. Check the PEM value.', 'woocommerce-pawapay' ) );
		}

		$digest_b64     = base64_encode( hash( 'sha512', $body_bytes, true ) );
		$content_digest = self::DIGEST_ALGORITHM . '=:' . $digest_b64 . ':';

		$created        = time();
		$expires        = $created + self::LIFETIME_SECONDS;
		$signature_date = gmdate( 'Y-m-d\TH:i:s', $created ) . '.000000Z';

		$values = array(
			'@method'        => strtoupper( $method ),
			'@authority'     => $authority,
			'@path'          => $path,
			'signature-date' => $signature_date,
			'content-digest' => $content_digest,
			'content-type'   => self::CONTENT_TYPE,
		);

		$covered_list = '("' . implode( '" "', self::COVERED ) . '")';
		$sig_params   = $covered_list . ';alg="' . self::ALGORITHM . '";keyid="' . $key_id . '";created=' . $created . ';expires=' . $expires;

		$base_lines = array();
		foreach ( self::COVERED as $component ) {
			$base_lines[] = '"' . $component . '": ' . $values[ $component ];
		}
		$base_lines[] = '"@signature-params": ' . $sig_params;
		$signature_base = implode( "\n", $base_lines );

		$der = '';
		$ok  = openssl_sign( $signature_base, $der, $key, OPENSSL_ALGO_SHA256 );
		if ( ! $ok ) {
			return new WP_Error( 'pawapay_sign_failed', __( 'pawaPay request signing failed.', 'woocommerce-pawapay' ) );
		}

		$raw = self::der_to_concat( $der, 32 );
		if ( null === $raw ) {
			return new WP_Error( 'pawapay_sign_encode', __( 'pawaPay signature encoding failed.', 'woocommerce-pawapay' ) );
		}

		return array(
			'Content-Digest'   => $content_digest,
			'Signature-Date'   => $signature_date,
			'Signature'        => 'sig-pp=:' . base64_encode( $raw ) . ':',
			'Signature-Input'  => 'sig-pp=' . $sig_params,
			'Accept-Signature' => self::ACCEPT_SIGNATURE,
			'Accept-Digest'    => self::ACCEPT_DIGEST,
		);
	}

	/**
	 * Verify a signed inbound callback from pawaPay.
	 *
	 * @param string $method      HTTP method (POST).
	 * @param string $authority   Host header observed on the request.
	 * @param string $path        Request path.
	 * @param array  $headers     Lowercased header map (single string values).
	 * @param string $body_bytes  Raw request body bytes.
	 * @param array  $keys_by_id  Map of keyid => PEM public key.
	 * @return true|WP_Error
	 */
	public static function verify_callback( $method, $authority, $path, $headers, $body_bytes, $keys_by_id ) {
		$sig_input = isset( $headers['signature-input'] ) ? $headers['signature-input'] : '';
		$sig       = isset( $headers['signature'] ) ? $headers['signature'] : '';
		$digest    = isset( $headers['content-digest'] ) ? $headers['content-digest'] : '';

		if ( '' === $sig_input || '' === $sig ) {
			return new WP_Error( 'pawapay_no_signature', 'Missing signature headers' );
		}

		// Parse the "sig-pp=(...)...;keyid=...;..." structure.
		$label_pos = strpos( $sig_input, '=' );
		if ( false === $label_pos ) {
			return new WP_Error( 'pawapay_bad_sig_input', 'Malformed Signature-Input' );
		}
		$params = substr( $sig_input, $label_pos + 1 );

		// Covered components inside the leading (...) list.
		if ( ! preg_match( '/^\(([^)]*)\)/', $params, $m ) ) {
			return new WP_Error( 'pawapay_bad_sig_input', 'No covered component list' );
		}
		$covered = array();
		if ( preg_match_all( '/"([^"]+)"/', $m[1], $cm ) ) {
			$covered = $cm[1];
		}

		$keyid = '';
		if ( preg_match( '/keyid="([^"]+)"/', $params, $km ) ) {
			$keyid = $km[1];
		}
		if ( '' === $keyid || ! isset( $keys_by_id[ $keyid ] ) ) {
			return new WP_Error( 'pawapay_unknown_keyid', 'Unknown or missing keyid: ' . $keyid );
		}

		// Validate Content-Digest against the actual body.
		if ( '' !== $digest ) {
			$expected_512 = 'sha-512=:' . base64_encode( hash( 'sha512', $body_bytes, true ) ) . ':';
			$expected_256 = 'sha-256=:' . base64_encode( hash( 'sha256', $body_bytes, true ) ) . ':';
			if ( ! hash_equals( $expected_512, $digest ) && ! hash_equals( $expected_256, $digest ) ) {
				return new WP_Error( 'pawapay_digest_mismatch', 'Content-Digest mismatch' );
			}
		}

		// Reconstruct the signature base from the covered components.
		$values = array(
			'@method'        => strtoupper( $method ),
			'@authority'     => $authority,
			'@path'          => $path,
			'signature-date' => isset( $headers['signature-date'] ) ? $headers['signature-date'] : '',
			'content-digest' => $digest,
			'content-type'   => isset( $headers['content-type'] ) ? $headers['content-type'] : '',
		);

		$base_lines = array();
		foreach ( $covered as $component ) {
			$val = isset( $values[ $component ] ) ? $values[ $component ] : ( isset( $headers[ $component ] ) ? $headers[ $component ] : '' );
			$base_lines[] = '"' . $component . '": ' . $val;
		}
		$base_lines[]   = '"@signature-params": ' . $params;
		$signature_base = implode( "\n", $base_lines );

		// Extract the raw signature bytes from "sig-pp=:<base64>:".
		if ( ! preg_match( '/:([^:]+):/', $sig, $sm ) ) {
			return new WP_Error( 'pawapay_bad_sig', 'Malformed Signature header' );
		}
		$raw = base64_decode( $sm[1], true );
		if ( false === $raw ) {
			return new WP_Error( 'pawapay_bad_sig', 'Signature is not valid base64' );
		}

		$der = self::concat_to_der( $raw );
		if ( null === $der ) {
			return new WP_Error( 'pawapay_bad_sig', 'Signature could not be DER-encoded' );
		}

		$pub = openssl_pkey_get_public( $keys_by_id[ $keyid ] );
		if ( false === $pub ) {
			return new WP_Error( 'pawapay_bad_pubkey', 'Public key could not be loaded' );
		}

		$result = openssl_verify( $signature_base, $der, $pub, OPENSSL_ALGO_SHA256 );
		if ( 1 === $result ) {
			return true;
		}
		return new WP_Error( 'pawapay_verify_failed', 'Signature verification failed' );
	}

	/**
	 * Convert a DER-encoded ECDSA signature to IEEE-P1363 raw r||s of fixed size.
	 *
	 * @param string $der        DER bytes.
	 * @param int    $coord_size Coordinate byte length (32 for P-256).
	 * @return string|null
	 */
	protected static function der_to_concat( $der, $coord_size ) {
		$offset = 0;
		$len    = strlen( $der );
		if ( $len < 2 || "\x30" !== $der[0] ) {
			return null;
		}
		$offset = 1;
		// Sequence length (assume short or single long-form byte; ECDSA P-256/384 fit).
		$seq_len = ord( $der[ $offset ] );
		$offset++;
		if ( $seq_len & 0x80 ) {
			$num_bytes = $seq_len & 0x7F;
			$offset   += $num_bytes; // Skip the multi-byte length; not needed further.
		}

		$read_int = function () use ( $der, &$offset, $len ) {
			if ( $offset >= $len || "\x02" !== $der[ $offset ] ) {
				return null;
			}
			$offset++;
			$int_len = ord( $der[ $offset ] );
			$offset++;
			$val = substr( $der, $offset, $int_len );
			$offset += $int_len;
			return $val;
		};

		$r = $read_int();
		$s = $read_int();
		if ( null === $r || null === $s ) {
			return null;
		}

		$r = self::pad_coord( $r, $coord_size );
		$s = self::pad_coord( $s, $coord_size );
		if ( null === $r || null === $s ) {
			return null;
		}
		return $r . $s;
	}

	/**
	 * Strip a leading sign byte / left-pad an integer to a fixed coordinate size.
	 *
	 * @param string $val        Big-endian integer bytes.
	 * @param int    $coord_size Target byte length.
	 * @return string|null
	 */
	protected static function pad_coord( $val, $coord_size ) {
		// Drop leading 0x00 padding bytes (DER sign byte).
		$val = ltrim( $val, "\x00" );
		if ( strlen( $val ) > $coord_size ) {
			return null;
		}
		return str_pad( $val, $coord_size, "\x00", STR_PAD_LEFT );
	}

	/**
	 * Convert IEEE-P1363 raw r||s to a DER-encoded ECDSA signature.
	 *
	 * @param string $raw Raw bytes (even length: r||s).
	 * @return string|null
	 */
	protected static function concat_to_der( $raw ) {
		$len = strlen( $raw );
		if ( 0 !== $len % 2 ) {
			return null;
		}
		$half = $len / 2;
		$r    = substr( $raw, 0, $half );
		$s    = substr( $raw, $half );

		$r = self::der_encode_int( $r );
		$s = self::der_encode_int( $s );
		$seq = $r . $s;
		return "\x30" . self::der_len( strlen( $seq ) ) . $seq;
	}

	/**
	 * DER-encode a positive integer (INTEGER tag, leading 0x00 if high bit set).
	 *
	 * @param string $val Big-endian bytes.
	 * @return string
	 */
	protected static function der_encode_int( $val ) {
		$val = ltrim( $val, "\x00" );
		if ( '' === $val ) {
			$val = "\x00";
		}
		if ( ord( $val[0] ) & 0x80 ) {
			$val = "\x00" . $val;
		}
		return "\x02" . self::der_len( strlen( $val ) ) . $val;
	}

	/**
	 * DER length encoding (short or long form).
	 *
	 * @param int $n Length.
	 * @return string
	 */
	protected static function der_len( $n ) {
		if ( $n < 0x80 ) {
			return chr( $n );
		}
		$bytes = '';
		while ( $n > 0 ) {
			$bytes = chr( $n & 0xFF ) . $bytes;
			$n   >>= 8;
		}
		return chr( 0x80 | strlen( $bytes ) ) . $bytes;
	}
}
