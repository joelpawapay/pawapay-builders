=== pawaPay for WooCommerce ===
Contributors: yourcompany
Tags: woocommerce, payments, mobile money, africa, pawapay
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
WC requires at least: 8.2
WC tested up to: 9.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Accept African mobile money payments on WooCommerce checkout via the pawaPay Merchant API v2.

== Description ==

pawaPay for WooCommerce lets your store collect mobile money payments across ~20 African
markets (MTN MoMo, M-Pesa, Airtel Money, Orange Money, Vodacom, Wave and more) directly on
the checkout page, using the pawaPay Merchant API v2.

Features:

* On-site checkout — customer enters their mobile money number; the plugin detects the
  provider automatically (via pawaPay's predict-provider) and initiates the deposit.
* Supports both the modern Cart/Checkout Blocks and the classic shortcode checkout.
* Handles all three pawaPay deposit authorisation flows: PROVIDER_AUTH (PIN prompt),
  PREAUTH (OTP, e.g. Orange Burkina Faso) and REDIRECT_AUTH (Wave).
* Asynchronous-safe: the order-received page polls for the final payment state, and a
  background reconciliation cron resolves anything missed by callbacks.
* RFC 9421 request signing (ECDSA P-256) and signed-callback verification.
* Refunds (full and partial) from the WooCommerce order screen.
* HPOS (High-Performance Order Storage) compatible.

== Installation ==

1. Upload the `woocommerce-pawapay` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to WooCommerce → Settings → Payments → pawaPay (Mobile Money).
4. Choose the environment (Sandbox or Production) and paste the matching API token.
5. (Recommended) Enable request signing and paste your ECDSA P-256 private key + key ID.
6. In your pawaPay dashboard, set the callback URL shown on the settings screen for both
   the DEPOSIT and REFUND operations, and whitelist pawaPay's callback IP range.
7. Make sure your store currency is one supported by pawaPay for your target markets.

== Frequently Asked Questions ==

= Does this need a build step? =

No. The Blocks integration script uses the WordPress/WooCommerce script globals directly,
so the plugin runs as-is without npm.

= How are refunds handled? =

Refunds are submitted to pawaPay immediately and confirmed asynchronously via callback. A
failed refund adds an order note for manual review (WooCommerce records the refund optimistically).

= What happens if a callback is missed? =

The order-received page polls the status endpoint, and a reconciliation cron checks any order
that has been pending for more than 15 minutes against pawaPay's status-check endpoint.

== Changelog ==

= 1.0.1 =
* Fix: order-received page could reload continuously after a completed payment
  (the status poller now reloads at most once per order).

= 1.0.0 =
* Initial release.
