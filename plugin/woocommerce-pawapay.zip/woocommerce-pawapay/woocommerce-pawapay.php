<?php
/**
 * Plugin Name:       pawaPay for WooCommerce
 * Plugin URI:        https://pawapay.io/
 * Description:       Accept mobile money payments across Africa (MTN MoMo, M-Pesa, Airtel, Orange, Wave and more) directly on your WooCommerce checkout via the pawaPay Merchant API v2.
 * Version:           1.0.1
 * Author:            Your Company
 * Author URI:        https://pawapay.io/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       woocommerce-pawapay
 * Domain Path:       /languages
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * WC requires at least: 8.2
 * WC tested up to:   9.4
 *
 * @package WooCommerce_PawaPay
 */

defined( 'ABSPATH' ) || exit;

define( 'WC_PAWAPAY_VERSION', '1.0.1' );
define( 'WC_PAWAPAY_PLUGIN_FILE', __FILE__ );
define( 'WC_PAWAPAY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WC_PAWAPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WC_PAWAPAY_GATEWAY_ID', 'pawapay' );

/**
 * Declare compatibility with WooCommerce features (HPOS + Cart/Checkout Blocks).
 * This is required by current WooCommerce guidelines.
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			// High-Performance Order Storage (custom order tables).
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				WC_PAWAPAY_PLUGIN_FILE,
				true
			);
			// Cart and Checkout Blocks.
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'cart_checkout_blocks',
				WC_PAWAPAY_PLUGIN_FILE,
				true
			);
		}
	}
);

/**
 * Boot the plugin once all plugins are loaded, guarding for WooCommerce.
 */
add_action( 'plugins_loaded', 'wc_pawapay_init', 11 );

function wc_pawapay_init() {
	if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Payment_Gateway' ) ) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="notice notice-error"><p>';
				echo esc_html__( 'pawaPay for WooCommerce requires WooCommerce to be installed and active.', 'woocommerce-pawapay' );
				echo '</p></div>';
			}
		);
		return;
	}

	require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-logger.php';
	require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-signer.php';
	require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-api.php';
	require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-gateway.php';
	require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-rest.php';

	// Register the gateway with WooCommerce (classic checkout + admin).
	add_filter(
		'woocommerce_payment_gateways',
		function ( $gateways ) {
			$gateways[] = 'WC_PawaPay_Gateway';
			return $gateways;
		}
	);

	// REST routes: callback receiver, status poller, phone validation proxy.
	WC_PawaPay_REST::instance()->init();

	// Reconciliation cron for stale pending orders.
	add_action( 'wc_pawapay_reconcile', array( 'WC_PawaPay_REST', 'reconcile_pending_orders' ) );

	// Convenience settings link on the plugins screen.
	add_filter(
		'plugin_action_links_' . plugin_basename( WC_PAWAPAY_PLUGIN_FILE ),
		function ( $links ) {
			$url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . WC_PAWAPAY_GATEWAY_ID );
			array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'woocommerce-pawapay' ) . '</a>' );
			return $links;
		}
	);
}

/**
 * Register the Cart/Checkout Blocks payment method integration.
 */
add_action(
	'woocommerce_blocks_loaded',
	function () {
		if ( ! class_exists( \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType::class ) ) {
			return;
		}
		require_once WC_PAWAPAY_PLUGIN_DIR . 'includes/class-wc-pawapay-blocks-support.php';
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function ( \Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $registry ) {
				$registry->register( new WC_PawaPay_Blocks_Support() );
			}
		);
	}
);

/**
 * Schedule the reconciliation cron on activation; clear it on deactivation.
 */
register_activation_hook(
	WC_PAWAPAY_PLUGIN_FILE,
	function () {
		if ( ! wp_next_scheduled( 'wc_pawapay_reconcile' ) ) {
			wp_schedule_event( time() + 300, 'wc_pawapay_five_minutes', 'wc_pawapay_reconcile' );
		}
	}
);

register_deactivation_hook(
	WC_PAWAPAY_PLUGIN_FILE,
	function () {
		$timestamp = wp_next_scheduled( 'wc_pawapay_reconcile' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'wc_pawapay_reconcile' );
		}
	}
);

/**
 * Custom 5-minute cron interval for reconciliation.
 */
add_filter(
	'cron_schedules', // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected
	function ( $schedules ) {
		if ( ! isset( $schedules['wc_pawapay_five_minutes'] ) ) {
			$schedules['wc_pawapay_five_minutes'] = array(
				'interval' => 300,
				'display'  => __( 'Every 5 minutes (pawaPay reconciliation)', 'woocommerce-pawapay' ),
			);
		}
		return $schedules;
	}
);
